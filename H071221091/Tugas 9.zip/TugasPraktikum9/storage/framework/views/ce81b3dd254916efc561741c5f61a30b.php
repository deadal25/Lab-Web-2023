

<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card mt-4 mb-4">
            <div class="card-header bg-info text-light">
                DATA PRODUK
            </div>
            <div class="card-body">
                <a href="<?php echo e(url('/produk/create')); ?>" class="btn btn-success btn-sm mb-3" title="Tambah Produk">
                    Tambah Prduk
                </a>
                <table class="table table-striped table-hover table-bordered">
                    <tr>
                        <th>Kode</th>
                        <th>Nama Produk</th>
                        <th>Kategori Produk</th>
                        <th>Stok</th>
                        <th>Harga</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->kodeProduk); ?></td>
                            <td><?php echo e($data->namaProduk); ?></td>
                            <td> <?php echo e($data->kategori); ?> </td>
                            <td> <?php echo e($data->stok); ?> </td>
                            <td> <?php echo e($data->harga); ?> </td>
                            
                            <td>
                                <a href="" title="Edit Produk"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit</button></a>
                                <a href="" title="Delete Produk"><button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash" aria-hidden="true"></i>Delete</button></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="card-footer bg-info"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum9\resources\views/index.blade.php ENDPATH**/ ?>