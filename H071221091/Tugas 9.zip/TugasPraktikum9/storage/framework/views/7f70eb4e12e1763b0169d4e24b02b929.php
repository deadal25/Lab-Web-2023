

<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('flash_message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('flash_message')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="card my-5" style="margin: 20px;">
            <div class="card-header bg-info">
                Input Produk Baru
            </div>
            <div class="card-body bg-light">
                <form action=" <?php echo e(url('produk')); ?> " method="post">
                    <?php echo csrf_field(); ?>


                    <div class="d-flex justify-content-between m-3">
                        <div class="form-group flex-grow-1">
                            <label for="kategori">Kategori Produk</label>
                            <select name="kategori" class="form-control">
                                <option value="">--Pilih--</option>
                                <option value="Samsung">Samsung</option>
                                <option value="Apple">Apple</option>
                            </select>
                        </div>
                        <div class="form-group flex-grow-2 mx-5">
                            <label for="kode">Kode Produk</label>
                            <input type="text" name="kode" id="kode" class="form-control"
                                value="<?php echo e($kodeProduk); ?>" readonly>
                        </div>
                    </div>

                    <div class="form-group m-3">
                        <label for="nama">Nama Produk</label>
                        <input type="text" name="nama" id="nama" class="form-control" required>
                    </div>

                    <div class="d-flex justify-content-between mx-5 my-3 g-5">
                        <div class="form-group flex-grow-1 mx-5">
                            <label for="stok">Stok Produk</label>
                            <input type="number" name="stok" id="stok" class="form-control" required>
                        </div>

                        <div class="form-group flex-grow-1 mx-5">
                            <label for="harga">Harga Produk</label>
                            <input type="number" name="harga" id="harga" class="form-control" required>
                        </div>
                    </div>

                    <input type="submit" value="Simpan" class="btn btn-success">
                </form>
            </div>
            <div class="card-footer bg-info"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum9\resources\views/create.blade.php ENDPATH**/ ?>