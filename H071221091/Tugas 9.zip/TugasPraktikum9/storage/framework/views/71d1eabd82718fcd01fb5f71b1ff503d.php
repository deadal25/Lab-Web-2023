

<?php $__env->startSection('title', 'Tambah Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <a href="<?php echo e(url('/kategori')); ?>" class="btn btn-primary btn-sm mb-3" title="Tambah Produk"><i
                class="fa-solid fa-arrow-left"></i> Back</a>

        <div class="card">
            <div class="card-header bg-info text-light">
                Input Kategori Baru
            </div>
            <div class="card-body bg-light">
                <form action=" <?php echo e(url('kategori')); ?> " method="post">
                    <?php echo csrf_field(); ?>


                    <div class="form-group m-3">
                        <label for="kategori">Kategori Produk</label>
                        <input type="text" name="kategori" id="kategori" class="form-control" required
                            autocomplete="off">
                    </div>

                    <div class="form-group m-3">
                        <label for="deskripsi">Deskripsi</label>
                        <input type="text" name="deskripsi" id="deskripsi" class="form-control" required
                            autocomplete="off">
                    </div>

                    <input type="submit" value="Simpan" class="btn btn-success">
                </form>
            </div>
            <div class="card-footer bg-info"></div>
        </div>

        <?php if(session('flash_message')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                <?php echo e(session('flash_message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(session('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                <?php echo e(session('error_message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum9\resources\views/kategori/create.blade.php ENDPATH**/ ?>