

<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="card mt-4 mb-4">
            <div class="card-header bg-info text-light">
                DATA PRODUK
            </div>
            <div class="card-body bg-light">
                <a href="<?php echo e(url('/kategori/create')); ?>" class="btn btn-success btn-sm mb-3" title="Tambah Produk">
                    Tambah Produk
                </a>
                <table class="table table-striped table-hover table-bordered">
                    <tr>
                        <th>Kategori Produk</th>
                        <th>Deskripsi Produk</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->kategoriProduk); ?></td>
                            <td><?php echo e($data->deskripsi); ?></td>

                            <td>
                                <a href="<?php echo e(url('/kategori/' . $data->kategoriProduk)); ?>" title="View Produk"><button class="btn btn-info btn-sm"><i class="fa fa-eye"aria-hidden="true"></i> View</button></a>
                                <a href="<?php echo e(url('/kategori/' . $data->kategoriProduk . '/edit')); ?>" title="Edit Produk"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"aria-hidden="true"></i> Edit</button></a>

                                <form action="<?php echo e(route('kategori.destroy', $data->kategoriProduk)); ?>" method="post" accept-charset="UTF-8" style="display:inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete Produk" onclick="return confirm('Yakin ingin Menghapus?')"><i class="fa-solid fa-trash" aria-hidden="true"></i> Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="card-footer bg-info"></div>
        </div>
        
        <?php if(session('flash_message')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                <?php echo e(session('flash_message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php elseif(session('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                <?php echo e(session('error_message')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TugasPraktikum9\resources\views/kategori/index.blade.php ENDPATH**/ ?>